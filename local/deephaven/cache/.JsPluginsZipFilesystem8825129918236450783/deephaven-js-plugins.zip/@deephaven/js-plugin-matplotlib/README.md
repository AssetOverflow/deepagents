# Deephaven matplotlib JS plugin

Display matplotlib plots in the Web UI. Requires [deephaven-plugin-matplotlib](https://pypi.org/project/deephaven-plugin-matplotlib/) to be installed on the server.

## Development

```
npm install
npm run build
```

Your output will be in `dist/index.js`
